# mavsim_template_files
#setup your environment for python

pip install numpy

pip install scipy

pip install pyopengl

pip install pyqtgraph

pip install pyqt5


#sometimes there are issues with that data_viewer if you have ROS installed on your system, in this case. If you are having problems

#with the data viewer try running the following in the commandline and then reinstalling pqt5

sudo apt autoremove pyqt5*
