% x_trim is the trimmed state,
% u_trim is the trimmed input
  
  
[A,B,C,D]=linmod('mavsim_trim',x_trim,u_trim);

A_lat = 
B_lat = 

A_lon = 
B_lon = 
  