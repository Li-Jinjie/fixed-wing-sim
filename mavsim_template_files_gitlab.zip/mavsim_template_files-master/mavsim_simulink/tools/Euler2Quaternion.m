
function quaternion = Euler2Quaternion(phi, theta, psi)
    % converts euler angles to a quaternion
    e0 = 
    e1 = 
    e2 = 
    e3 = 
    quaternion = [e0; e1; e2; e3];
end
