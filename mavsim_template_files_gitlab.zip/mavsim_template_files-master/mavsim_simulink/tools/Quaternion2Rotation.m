function R = Quaternion2Rotation(quaternion)
    %converts a quaternion attitude to a rotation matrix
    e0 = quaternion(1);
    e1 = quaternion(2);
    e2 = quaternion(3);
    e3 = quaternion(4);

    R = 
end
